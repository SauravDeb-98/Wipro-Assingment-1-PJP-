import java.util.Scanner;

public class one {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        if (a==0){
            System.out.println("It is zero");
        }
        else if(a>0){
            System.out.println("It is positive");
        }
        else{
            System.out.println("It is negative");
        }


    }

}
