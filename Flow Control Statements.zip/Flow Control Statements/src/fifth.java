import java.util.Scanner;

public class fifth{
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        char ch=  input.next().charAt(0);
        if((ch >= 97 && ch <= 122) || (ch >= 65 && ch <= 90))
        {
            System.out.println("Alphabet");
        }
        else if(ch >= 48 && ch <= 57)
        {
            System.out.println("Digit");
        }
        else
        {
            System.out.println("Special Character");
        }

    }
}