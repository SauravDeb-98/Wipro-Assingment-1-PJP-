import java.util.Scanner;

public class nineteen {
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        int first = input.nextInt();
        int last = input.nextInt();
        int i;

        for(i=first;i<=last;i++){
            if(i%2==0 && i%3==0 && i%5==0){
                System.out.println(i);
            }
            else {

            }
        }
    }
}
