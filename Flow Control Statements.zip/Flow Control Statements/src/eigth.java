import java.util.Scanner;

public class eigth {
    public static void main(String args[])
    {
        Scanner input = new Scanner(System.in);
        String color = input.nextLine();
        if(color.equals("R")){
            System.out.println("Red");
        }
        else if(color.equals("B")){
            System.out.println("Blue");
        }
        else if(color.equals("G")){
            System.out.println("Green");
        }
        else if(color.equals("O")){
            System.out.println("Orange");
        }
        else if(color.equals("Y")){
            System.out.println("Yellow");
        }
        else if(color.equals("W")){
            System.out.println("White");
        }
        else{
            System.out.println("Invalid Code");
        }

    }
}
