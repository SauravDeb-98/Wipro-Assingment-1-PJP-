import java.util.Scanner;

public class sixteen
{
    //
    public static void printStars(int n)
    {
        int i;
        int j;


        for(i=0; i<n; i++)
        {


            for(j=0; j<=i; j++)
            {

                System.out.print("* ");
            }


            System.out.println();
        }
    }


    public static void main(String args[])
    {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();

        printStars(n);
    }
}
