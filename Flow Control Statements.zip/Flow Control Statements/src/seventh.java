import java.awt.*;
import java.util.Scanner;

public class seventh {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        String S1= input.nextLine();
        String S2 ;
        String S3;
        //Convert to LowerCase
        S2= S1.toLowerCase();
        S3= S1.toUpperCase();
        if(S1.equals(S2)){
            System.out.println(S3);
        }
        else {
            System.out.println(S2);
        }




    }
}
